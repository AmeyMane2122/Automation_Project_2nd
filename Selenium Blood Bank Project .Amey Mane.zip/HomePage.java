package bloodBankTodayProject;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;

public class HomePage
{

	public static void main(String[] args) throws InterruptedException, IOException 
	{
		
		Select s;
		System.setProperty("webdriver.chrome.driver","C:\\Users\\manem\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromeDriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		//URL
		driver.get("https://bloodbanktoday.com/");
		Thread.sleep(2000);
		
		// HOME PAGE
		
		// [1]Blood Group (AB+)
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_cboBlood-button")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("ui-id-5")).click();
		Thread.sleep(2000);
		
		// [2]Select State (Maharashtra)
		s= new Select(driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboState\"]")));
		Thread.sleep(2000);
		s.selectByVisibleText("Maharashtra");
		Thread.sleep(2000);
		
		// [3]Select District (Kolhapur)
		s=new Select(driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboCity\"]")));
		Thread.sleep(2000);
		s.selectByVisibleText("Kolhapur");
		Thread.sleep(2000);
		
		// [4]Select Tehsil (Karvir)
		s= new Select(driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboTeh\"]")));
		Thread.sleep(2000);
		s.selectByVisibleText("Karvir");
		Thread.sleep(2000);
		
		// Click On FIND BLOOD button
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_btnSave")).click();
		Thread.sleep(2000);
		
		// Screenshot  of Output Window
		File f=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		Files.copy(f, new File("C:\\Users\\manem\\OneDrive\\Desktop\\Automation Testing\\FindBloodOutput.jpg"));
		

	}

}
