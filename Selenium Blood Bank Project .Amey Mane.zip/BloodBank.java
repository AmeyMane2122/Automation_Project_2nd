package bloodBankTodayProject;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;

public class BloodBank
{

	public static void main(String[] args) throws InterruptedException, IOException 
	{
		Select s;
		WebElement w;
		WebElement w1;
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\manem\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromeDriver.exe");
		
		
		WebDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		//URL
		driver.get("https://bloodbanktoday.com/");
		Thread.sleep(2000);
		
		// Click on BLOOD BANK
		w= driver.findElement(By.xpath("//*[@id=\"aspnetForm\"]/header/div[2]/div/div/nav/div[2]/ul/li[2]/a"));
		w.click();
		Thread.sleep(2000);
		
		driver.navigate().refresh();
		
		// To handle Stale Element Reference Exception Error
		try               
		{
			w.click();
		}
		catch(StaleElementReferenceException e)
		{
			w= driver.findElement(By.xpath("//*[@id=\"aspnetForm\"]/header/div[2]/div/div/nav/div[2]/ul/li[2]/a"));
		}
		
		driver.findElement(By.xpath("//*[@id=\"aspnetForm\"]/header/div[2]/div/div/nav/div[2]/ul/li[2]/a")).click();
		
		
		// Scroll Till SEARCH
		JavascriptExecutor js= (JavascriptExecutor)driver;
		
		js.executeScript("window.scrollBy(0,400);");
		Thread.sleep(4000);
		
		// Handle DropDowns
		//[1] Select State (Maharashtra)
		s= new Select(driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboState\"]")));
		Thread.sleep(2000);
		s.selectByVisibleText("Maharashtra");
		
		// [2] Select District
		s= new Select(driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboCity\"]")));
		Thread.sleep(2000);
		s.selectByVisibleText("Kolhapur");
		
		// Click on SEARCH button
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_btnSave")).click();
		Thread.sleep(2000);
	
		// Take Screenshot
		File f=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		Files.copy(f, new File("C:\\Users\\manem\\OneDrive\\Desktop\\Automation Testing\\FindBloodBanksInIndia.jpg"));
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
