package bloodBankTodayProject;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Blogs
{

	public static void main(String[] args) throws InterruptedException
	{
		WebElement w;
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\manem\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromeDriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		//URL
		driver.get("https://bloodbanktoday.com/");
		Thread.sleep(2000);
		
		// Click on BLOGS
		w=driver.findElement(By.linkText("BLOGS"));
		w.click();
		Thread.sleep(2000);
		
		driver.navigate().refresh();
		
		// To handle Stale Element Reference Exception Error
		try               
		{
			w.click();
		}
		catch(StaleElementReferenceException e)
		{
			w= driver.findElement(By.linkText("BLOGS"));
		}
		
		driver.findElement(By.linkText("BLOGS")).click();
		Thread.sleep(4000);
		
		//Click on Read More
		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_UpdatePanel1\"]/div/div/div[1]/div[1]/div/div[3]/div/div/a")).click();
		Thread.sleep(4000);
		
		//ScrollPageDown
		JavascriptExecutor js= (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,900)");
		Thread.sleep(4000);
		
		//ScrollPageUp
		js.executeScript("window.scrollBy(0,-900)");
		Thread.sleep(4000);
		
		
		//BackToHomePage
		driver.findElement(By.linkText("HOME")).click();
		
		
		
		
		
		
		
		
		
		

	}

}
