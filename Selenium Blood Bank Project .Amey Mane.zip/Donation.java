package bloodBankTodayProject;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Donation
{

	public static void main(String[] args) throws InterruptedException 
	{
		WebElement w;

		System.setProperty("webdriver.chrome.driver","C:\\Users\\manem\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromeDriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		//URL
		driver.get("https://bloodbanktoday.com/");
		Thread.sleep(2000);
		
		//Click on DONATE US button
		
		w= driver.findElement(By.linkText("DONATE US"));
		w.click();
		Thread.sleep(2000);
		
		driver.navigate().refresh();
		
		// To handle Stale Element Reference Exception Error
		try               
		{
			w.click();
		}
		catch(StaleElementReferenceException e)
		{
			w= driver.findElement(By.linkText("DONATE US"));
		}
		
		driver.findElement(By.linkText("DONATE US")).click();
		
		
		//Select Amount
		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_rbtAmount\"]/tbody/tr/td[4]/label")).click();
		
		//Enter Name
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtName")).sendKeys("Amey Mane");
		Thread.sleep(2000);
		
		//Enter Email
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtEmail")).sendKeys("mane.meya@gmail.com");
		Thread.sleep(2000);
		
		//Enter Phone Number
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtMobile")).sendKeys("8329341995");
		Thread.sleep(2000);
		
		//Enter Country
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtCountry")).sendKeys("India");
		Thread.sleep(2000);
		
		//Enter State
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtState")).sendKeys("Maharashtra");
		Thread.sleep(2000);
		
		//Enter City
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtCity")).sendKeys("Kolhapur");
		Thread.sleep(2000);
		
		//Enter PinCode
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtPinCode")).sendKeys("416007");
		Thread.sleep(2000);
		
		//Enter Address
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtAddress")).sendKeys("Kolhapur");
		Thread.sleep(2000);
		
		//Display or Hide name in List
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_cboDisplayType-button")).click();
		driver.findElement(By.xpath("//*[@id=\"ui-id-1\"]")).click();
		Thread.sleep(2000);
		
		//Click on DONATE NOW button
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_btnSave")).click();
		Thread.sleep(2000);
		
		
		
		
		
		
		
		
		
		
	}

}
