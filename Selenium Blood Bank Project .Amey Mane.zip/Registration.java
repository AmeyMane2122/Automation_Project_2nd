package bloodBankTodayProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Registration
{

	public static void main(String[] args) throws InterruptedException 
	{
		Select s;                              // Global Declaration
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\manem\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromeDriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		//URL
		driver.get("https://bloodbanktoday.com/");
		Thread.sleep(2000);
		
		//Registration Button
		driver.findElement(By.linkText("REGISTER")).click();
		Thread.sleep(2000);
		
		//First Name
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtName")).sendKeys("Amey A.Mane");
		Thread.sleep(2000);
		
		//Email
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtEmail")).sendKeys("mane.ameya@gmail.com");
		Thread.sleep(2000);
		
		//Mobile Number
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtMobile")).sendKeys("7329341995");
		Thread.sleep(2000);
		
		//Create PassWord
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtLoginPassword")).sendKeys("Ameya2122");
		Thread.sleep(2000);
		
		//BloodGroup as O+
		driver.findElement(By.className("ui-selectmenu-text")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("ui-id-9")).click();
		Thread.sleep(3000);
			
		//Gender as Male
		driver.findElement(By.xpath("//span[@id=\"ctl00_ContentPlaceHolder1_cboGender-button\"]")).click();
		driver.findElement(By.xpath("//div[@id=\"ui-id-10\"]")).click();
		Thread.sleep(2000);
		
		//BirthDate as 28
		s=new Select(driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboDobDay\"]")));
		s.selectByIndex(27); 
		Thread.sleep(2000);
		
		
		//BirthMonth as September
		s=new Select(driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboDobMonth\"]")));
		s.selectByIndex(8); 
		Thread.sleep(2000);
		 
		//BirthYear as 1997  
		s=new Select(driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboDobYear\"]")));
		s.selectByIndex(4); 
		Thread.sleep(2000);
		 
		//Weight as 58
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtWeight")).sendKeys("58"); 
		Thread.sleep(2000);
		
	    //Donation Date >> Day 
		s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboLastDay\"]"))));
		s.selectByIndex(5); Thread.sleep(2000);
		
		//Donation Date >> Month 
		s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboLastMonth\"]"))));
		s.selectByIndex(7); 
		Thread.sleep(2000);
		 
		//Donation Date >> Year 
		s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboLastYear\"]"))));
		s.selectByIndex(2);
		Thread.sleep(2000);
		  
		//Show Mobile
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_cboShowMobile-button")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("ui-id-13")).click(); 
		Thread.sleep(2000);
		 
		
		//Show SMS Alert
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_cboSmsAlert-button")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("ui-id-16")).click();
		Thread.sleep(2000);
		
		
		//PinCode
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtPinCode")).sendKeys("416007");
		Thread.sleep(2000);
		
		//Select State as Maharashtra
		s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboState\"]"))));
		s.selectByVisibleText("Maharashtra");
		Thread.sleep(2000);
		
		
		//Select District as Kolhapur
		s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboCity\"]"))));
		s.selectByVisibleText("Kolhapur");
		Thread.sleep(2000);
		
		//Select Tehsil as Karvir
		s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboTeh\"]"))));
		s.selectByVisibleText("Karvir");
		Thread.sleep(2000);
		
		//Enter City or Village
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtAddress")).sendKeys("Kolhapur");
		Thread.sleep(2000);
		
		//Check Terms and Conditions
		driver.findElement(By.name("ctl00$ContentPlaceHolder1$chkTerms")).sendKeys("checked");
		Thread.sleep(2000);
	
		
		//SUBMIT button
	     driver.findElement(By.id("ctl00_ContentPlaceHolder1_btnSave")).click();
	     Thread.sleep(2000);
		
		
		
	
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
		
		

	}

}
